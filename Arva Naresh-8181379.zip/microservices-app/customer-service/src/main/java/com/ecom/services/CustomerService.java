package com.ecom.services;

import com.ecom.dto.ProductCatalogueRequest;
import com.ecom.dto.ProductResponse;
import com.ecom.entities.Customer;

import java.util.List;

public interface CustomerService {

    Customer create(Customer customer);

    Customer getById(Long id);

    List<Customer> getAll();

    Customer update(Long id, Customer customer);

    void delete(Long id);
}