package com.virtusa.order.entities;

public enum OrderStatus {
    CREATED, CANCELLED, COMPLETED
}